package com.example.todo;

import android.app.Dialog;
import android.content.DialogInterface;

public interface OnDialogCloseListner {
    void onDialogClose(DialogInterface dialogInterface);
}
